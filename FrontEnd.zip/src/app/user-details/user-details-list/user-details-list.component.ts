import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-details-list',
  templateUrl: './user-details-list.component.html',
  styleUrls: ['./user-details-list.component.css']
})
export class UserDetailsListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
